package cn.coding.com.springbootmqtt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMqttApplicationTests {

    @Test
    void contextLoads() {
    }

}
